import tkinter as tk
from tkinter import messagebox

class GearChecklistWindow:
    def __init__(self, root):
        self.window = tk.Toplevel(root)
        self.window.title("Gear Checklist")
        self.label = tk.Label(self.window, text="Gear Checklist", font=("Helvetica", 14))
        self.label.pack(pady=10)

        self.checklist_entry = tk.Entry(self.window, width=50)
        self.checklist_entry.pack(pady=10)

        self.save_button = tk.Button(self.window, text="Save", command=self.save_checklist)
        self.save_button.pack(pady=5)

        self.back_button = tk.Button(self.window, text="Back", command=self.window.destroy)
        self.back_button.pack(pady=10)

    def save_checklist(self):
        if not self.checklist_entry.get():
            messagebox.showerror("Error", "Checklist cannot be empty.")
        else:
            messagebox.showinfo("Saved", "Checklist saved successfully!")
