import tkinter as tk
from tkinter import messagebox
from seasons import SeasonsWindow
from tracking_tips import TrackingTipsWindow
from gear_checklist import GearChecklistWindow

class MainApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Hunter's Guide")
        
        # Home Page Widgets
        self.home_label = tk.Label(root, text="Welcome to Hunter's Guide", font=("Helvetica", 16))
        self.home_label.pack(pady=20)
        
        self.seasons_button = tk.Button(root, text="Season Schedules", command=self.open_seasons_window)
        self.seasons_button.pack(pady=10)

        self.tips_button = tk.Button(root, text="Tracking & Trapping Tips", command=self.open_tips_window)
        self.tips_button.pack(pady=10)

        self.checklist_button = tk.Button(root, text="Gear Checklist", command=self.open_checklist_window)
        self.checklist_button.pack(pady=10)

        self.exit_button = tk.Button(root, text="Exit", command=self.exit_app)
        self.exit_button.pack(pady=10)

    def open_seasons_window(self):
        SeasonsWindow(self.root)

    def open_tips_window(self):
        TrackingTipsWindow(self.root)

    def open_checklist_window(self):
        GearChecklistWindow(self.root)

    def exit_app(self):
        if messagebox.askyesno("Exit", "Are you sure you want to exit?"):
            self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = MainApp(root)
    root.mainloop()
