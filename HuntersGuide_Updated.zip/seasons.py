import tkinter as tk
from PIL import Image, ImageTk

class SeasonsWindow:
    def __init__(self, root):
        self.window = tk.Toplevel(root)
        self.window.title("Season Schedules")
        
        # Load and display the image
        img = Image.open("images/seasons.png")
        img = img.resize((400, 300), Image.ANTIALIAS)
        self.photo = ImageTk.PhotoImage(img)
        self.image_label = tk.Label(self.window, image=self.photo)
        self.image_label.pack(pady=10)
        
        # Add hunting season information
        self.label = tk.Label(self.window, text="Indiana Hunting Seasons", font=("Helvetica", 14))
        self.label.pack(pady=10)
        
        self.info = tk.Label(self.window, text=(
            "Mourning Dove: Sept. 1 - Oct. 16, Nov. 1 - 27, Dec. 17 - Jan. 2\n"
            "Woodcock: Oct. 15 - Nov. 28\n"
            "Ducks, Coots, Mergansers: Oct. 29 - Nov. 6, Dec. 26 - Jan. 22\n"
            "Geese: Sept. 10 - 18, Oct. 22 - 30, Nov. 19 - Feb. 12\n"
        ), justify="left", font=("Helvetica", 12))
        self.info.pack(pady=10)
        
        self.back_button = tk.Button(self.window, text="Back", command=self.window.destroy)
        self.back_button.pack(pady=10)
