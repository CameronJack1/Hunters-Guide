import tkinter as tk

class TrackingTipsWindow:
    def __init__(self, root):
        self.window = tk.Toplevel(root)
        self.window.title("Tracking and Trapping Tips")
        self.label = tk.Label(self.window, text="Tracking and Trapping Tips", font=("Helvetica", 14))
        self.label.pack(pady=10)
        self.back_button = tk.Button(self.window, text="Back", command=self.window.destroy)
        self.back_button.pack(pady=10)
