# Add utility functions for input validation or other reusable logic here
